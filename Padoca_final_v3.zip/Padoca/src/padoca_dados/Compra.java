package padoca_dados;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Compra{

    public void atualiza_quantidade (){
     
    }
    
    public static void adicionar_carrinho (){
            List<String> result = null;
            
            //Criamos um objeto Produto e setamos em seus atributos
            //as posições correspondentes do array
            Produto u = new Produto();
           
       
            for (String s : result) {

                String[] produto = s.split(";");
     
                u.setId_prod(Integer.valueOf(produto[0]));
                u.setQtd_prod(Integer.valueOf(produto[1]));
                u.setPreco_prod(Double.valueOf(produto[3]));
                
                
                
                //exibe o conteúdo do objeto u
                //System.out.println(u.toString());
            }
        
    }
    
    
   public static void salvar_arquivo(List<Produto> produtos) {
       File dir = new File("/Padoca");
        //Cria um novo arquivo
       if (dir.exists()) {

       }else {
           new File("/Padoca").mkdir();
       }
       File arq = new File(dir, "Produtos.txt");

        try {
            arq.createNewFile();
            FileWriter fileWriter = new FileWriter(arq, true);
            //Utilizamos o método print() para escrever na
            // mesma linha e um ponto e vírgula no final.
            //O println forçará a troca de linha
            // para o próximo produto.
            try (PrintWriter printWriter = new PrintWriter(fileWriter)) {
                for (Produto produto : produtos) {
                    printWriter.print(produto.getId_prod() + ";");
                    printWriter.print(produto.getQtd_prod() + ";");
                    printWriter.print(produto.getNome_prod() + ";");
                    printWriter.println(produto.getPreco_prod());
                }
                printWriter.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
}

}