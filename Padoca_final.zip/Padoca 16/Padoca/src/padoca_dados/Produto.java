package padoca_dados;

import java.util.List;
import java.util.Scanner;


public class Produto {

	private int id_prod;
	private int qtd_prod;
        private double preco_prod;
	private String nome_prod;
	private double total_comp;
        
	Scanner sc = new Scanner(System.in);
		
	public int getId_prod() {
		return id_prod;
	}
	
	public int getQtd_prod() {	
		return qtd_prod;
	}
	
	public String getNome_prod() {
		return nome_prod;
	}
        
        public double getPreco_prod(){
                return preco_prod;
        }
        
        public double getTotal_comp(){
                return total_comp;
        }
        
        public void setId_prod (int id_prod) {
            this.id_prod = id_prod;
        }
        
         public void setQtd_prod(int qtd_prod){
            this.qtd_prod = qtd_prod;
        }
        public void setNome_prod(String nome_prod) {
            this.nome_prod = nome_prod;
        }
        public void setPreco_prod (double preco_prod) {
            this.preco_prod = preco_prod;
        }
        
        public void setTotal_comp (double preco_prod) {
            this.total_comp += preco_prod;
        }
        
        public static void atualizar_produto (Produto atualizar){
        //Realiza baixa no estoque e atualiza o arquivo com novos dado
        
        List<Produto> estoque = Estoque.get_Estoque();
        
            for(Produto lista_estoque : estoque){
                if (atualizar.getId_prod() == lista_estoque.getId_prod()){
                    lista_estoque.setQtd_prod(lista_estoque.getQtd_prod() + atualizar.getQtd_prod()) ;    
                }
        }
        Estoque.atualizar_arquivo (estoque);
    }
        
        public void insere(int id_prod, int qtd_prod, String nome_prod, double preco_prod){
            
            this.id_prod = id_prod;
            this.qtd_prod = qtd_prod;
            this.nome_prod = nome_prod;
            this.preco_prod = preco_prod;
            
            
        }
}