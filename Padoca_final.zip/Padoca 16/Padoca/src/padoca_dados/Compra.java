package padoca_dados;


import java.util.ArrayList;
import java.util.List;

public class Compra{
    private static List<Produto> carrinho;
    private static double valor_total;
    
    
    public static void finalizar_compra (){
        //Realiza baixa no estoque e atualiza o arquivo com novos dados
        List<Produto> encerrar_compra = get_Carrinho();
        List<Produto> estoque_final = Estoque.get_Estoque();
        
        for (Produto lista_carrinho : encerrar_compra){
            for(Produto lista_estoque : estoque_final){
                if (lista_carrinho.getId_prod() == lista_estoque.getId_prod()){
                    lista_estoque.setQtd_prod(lista_estoque.getQtd_prod() - lista_carrinho.getQtd_prod()) ;    
                }
            }
        }
        Estoque.atualizar_arquivo (estoque_final);
    }
    
    public static List<Produto> get_Carrinho(){
        return carrinho;
    }
    
    public static double get_Valor_total (){
        return valor_total;
    }
    
    
    
    public static void construir_carrinho (){
        valor_total = 0;
        Compra.carrinho = new ArrayList();
    }
    
    public static void adicionar_carrinho (Produto novo){
        Compra.carrinho.add(novo);
        valor_total+=(novo.getQtd_prod())*(novo.getPreco_prod());
        
    }
}
    
    
  