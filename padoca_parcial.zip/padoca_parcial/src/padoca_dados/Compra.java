package padoca_dados;

public class Compra {
    
}
