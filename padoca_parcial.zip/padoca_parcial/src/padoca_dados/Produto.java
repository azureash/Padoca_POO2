package padoca_dados;

import java.util.Scanner;

public class Produto {

	private int id_prod;
	private int qtd_prod;
        private double preco_prod;
	private String nome_prod;
	
	Scanner sc = new Scanner(System.in);
		
	public int getId_prod() {
		return id_prod;
	}
	
	public int getQtd_prod() {	
		return qtd_prod;
	}
	
	public String getNome_prod() {
		return nome_prod;
	}
        
        public double getPreco_prod(){
                return preco_prod;
        }
        
        void insere(int id_prod, int qtd_prod, String nome_prod, double preco_prod){
            
            id_prod = this.getId_prod();
            qtd_prod = this.getQtd_prod();
            nome_prod = this.getNome_prod();
            preco_prod = this.getPreco_prod();
            
            
        }
        
}

