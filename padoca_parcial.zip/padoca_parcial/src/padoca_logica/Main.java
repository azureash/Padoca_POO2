package padoca_logica;
import java.util.Scanner;
import padoca_dados.Produto;
import padoca_dados.Compra;

public class Main {
    public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    
    Produto P = new Produto();
    
      System.out.println("ID do produto: ");
      P.getId_prod();
    
//    	System.out.println("Quantidade do produto: ");
//	qtd_prod = sc.nextInt();
//    
//		System.out.println("Nome do produto: ");
//		nome_prod = sc.next();
//				
	

    
    }    
}
