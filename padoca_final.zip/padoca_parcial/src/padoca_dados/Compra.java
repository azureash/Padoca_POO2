package padoca_dados;

import java.util.Scanner;

/** Classe compra
*
@author marina
*
*/

public class Compra {
 
    private int id_compra;
    private int qtd_compra;
    private float total_carrinho;
    
    Scanner sc = new Scanner(System.in);
		
	public int getId_compra() {
		return id_compra;
	}
        
                  public void setId_compra (int id_compra) {
                                    this.id_compra = id_compra;
                  }
        
    	public int getQtd_compra() {	
		return qtd_compra;
	}
        
                  public void setQtd_compra(int qtd_compra) {
                                    this.qtd_compra = qtd_compra;
        
                  }
        
                 public float gettotal_carrinho() {
                                    return total_carrinho;
                
                 }
                 
                 public void setTotal_carrinho(float total_carrinho) {
                                    this.total_carrinho = total_carrinho;
                
                 }
        
                
         void inserir(int id_compra, int qtd_compra, float total_carrinho){
            
                  this.id_compra = id_compra;
                  this.qtd_compra = qtd_compra;
                  this.total_carrinho = total_carrinho;
            
        }
        
}
